Conf file examples for Splunking the Endpoint
.conf2015 and .conf2016
brodsky@splunk.com
UPDATED 5/1/2016!
UPDATED 9/22/2016!
UPDATED 10/3/2016!

Three files included:

1) Registry key monitor inputs (WinRegMon) that map to all of the keys that
are identified in Microsoft Sysinternals "Autoruns" version 13.4:

https://technet.microsoft.com/en-us/sysinternals/bb963902.aspx

2) ALTERNATE Registry key monitor inputs with different formats: some people were
seeing issues with forwarder configs - use this alternative format if you 
are seeing lots of errors in splunkd.log and are not seeing the registry
checkpoint files get created. Thank you, Richard Griffith!

3) sysmon configuration file that excludes Network connection data and splunk
forwarder related data. Download sysmon here:

https://technet.microsoft.com/en-us/sysinternals/dn798348

Get sysmon TA here:

https://splunkbase.splunk.com/app/1914/

4) ALTERNATE sysmon config file tested for version 4.12 of sysmon (sysmoncfg_v31.xml).

5) LOOKUP file from Jim Apger, windows_event_descriptions.csv. “Commonly known” windows executable names. You can use a search like this (tstats enabled, and will work against the Application State out of the CIM app). Determine when processes are masquerading as known windows process names but not running out of the right directories. Very useful because this will complete much faster than a search against _raw and enables better ability to react.

 | tstats count
   FROM datamodel=Application_State.All_Application_State
   WHERE All_Application_State.process!="C:\\Windows\\System32*"
   BY _time,host,All_Application_State.process,All_Application_State.user
|rename All_Application_State.process as process All_Application_State.user as user
| rex field=process .*\\\(?<filename>\S+)\s?$ | lookup isWindowsSystemFile_lookup filename
| search isWindowsSystemFile=1

